#PyGit __init__.py
from .__version__ import __version__

