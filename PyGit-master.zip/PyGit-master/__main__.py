#!/usr/bin/python3
import sys
sys.path.append('pygit')
from pygit import
if __name__ == "__main__":
    PyGit.initialise()

