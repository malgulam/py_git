#pygit __init__.py
from pathlib import Path
BASE_DIR = Path.home()
DESKTOP = BASE_DIR / 'Desktop'
SHELF_DIR = str(BASE_DIR) +'/'+ 'python-git-shelf'