#core __init__.py
import sys
sys.path.append('.')
from core.Commands import Commands
