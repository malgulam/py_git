# PyGit
Python Git VC Tool.
This package acts as a version control tool that helps python developers to create,edit,etc from within the program itself.

eg.)import pygit
#main code
#
#
#
pygit.pygit_vc(f"{this_file's_name}")

You will be given prompts.Respond accrodingly.

Much contribution will be needed.Thanks in advance. :]
